import java.sql.*;

public class JDBCConnector
{

  public static void main(String[] args)
  {
	  Connection con = null;
	  ResultSet rs = null;
	  
    try
    {
      Class.forName("com.mysql.cj.jdbc.Driver");  
	  
	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/books?useSSL=false&allowPublicKeyRetrieval=true", "root", "root");
      
      String preparedSQL = "SELECT * FROM books";
		
    	PreparedStatement ps = con.prepareStatement (preparedSQL);
    			
    	rs = ps.executeQuery ();

		while (rs.next ()) {            
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getInt(3));
		}

		rs.close ();
        rs = null;        
        con.close ();    		
    }
    catch (Exception e)
    {
      System.err.println("Got an exception! ");
      System.err.println(e);
    }
  }
}
