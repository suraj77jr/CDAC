
## Building and running

### Building
1. Create your app in a directory.
2. Add a file by the name `Dockerfile` to give build instructions  in the same directory
3. Build the app using `docker build -t name:tag path`
`-t` is the tag option. Image can be built by removing the `-t "tagName"` but then the generated image won't have any name


### [**Dockerfile**](https://docs.docker.com/engine/reference/builder/)
```
FROM openjdk:12-alpine
COPY . ~/rohan/sdm/docker/workdir
WORKDIR ~/rohan/sdm/docker/workdir
RUN javac HelloWorldWithoutTag.java
CMD ["java", "HelloWorld"]
```

- `FROM` 
	- Initializes a new build stage and sets the Base image for subsequent instructions. 
	- A valid `Dockerfile` must start with a `FROM` instruction. 
	- The base image can be any valid image.
- `COPY` 
	- copy the sourcecode to the working directory
- `ADD` 
	- similar to `COPY`, but can also handle URLs and can extract tar files.
- `WORKDIR` 
	- Specify the working directory
- `RUN` 
	- Compilation instructions
	-  `RUN <command>` (_shell_ form, the command is run in a shell, which by default is `/bin/sh -c` on Linux or `cmd /S /C` on Windows)
	- `RUN ["executable", "param1", "param2"]` (_exec_ form)
	The `RUN` instruction will execute any commands in a new layer on top of the current image and commit the results. The resulting committed image will be used for the next step in the `Dockerfile`.
- `ENV`
	- sets environment variables in the Docker image. 
- `CMD`
	- Has three form s
		- `CMD ["executable","param1","param2"]` (_exec_ form, this is the preferred form)
		- `CMD ["param1","param2"]` (as _default parameters to ENTRYPOINT_)
		- `CMD command param1 param2` (_shell_ form)
	- There can only be one `CMD` instruction in a `Dockerfile`. If you list more than one `CMD` then only the last `CMD` will take effect.
	- **The main purpose of a `CMD` is to provide defaults for an executing container.** These defaults can include an executable, or they can omit the executable, in which case you must specify an `ENTRYPOINT` instruction as well.

### Run
`docker run ImageName `


### Other useful commands
- `docker ps -a`
	- List all the images
- 













### lab work

#### mysql 
```
docker run --name mysql-submission -e MYSQL_ROOT_PASSWORD=Rohan@123 -d -p 3307:3306 mysql
```console
docker run --name some-mysql -e MYSQL_ROOT_PASSWORD=my-secret-pw -d mysql:tag
```



```console
```console
$ docker exec -it some-mysql bash
```