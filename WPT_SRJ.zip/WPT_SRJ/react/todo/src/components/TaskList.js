import React from "react" ;
import TaskCard from "./TaskCard";

const TaskList = (props)=>{
    console.log(props)

    const renderTaskList = props.tasks.map((task) => {
        return (
            <TaskCard 
                task = {task} 
                key={task.id}
            />
        );      
    });
    return <div>
        
        
        {renderTaskList}</div>;
};

export default TaskList ;