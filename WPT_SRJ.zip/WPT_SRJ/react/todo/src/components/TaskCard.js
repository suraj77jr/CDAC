import React from "react";

const TaskCard = (props) => {
  const { id, task, duration } = props.task;
  return (
    <div className="item">

      <div className="content">
        <div className="header">{task}</div>
        <div>{duration}</div>
      </div>
    </div>
  );
};

export default TaskCard;