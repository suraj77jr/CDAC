import React, { useState, useEffect } from "react";
import logo from './logo.svg';
import './App.css';
import { v4 as uuid } from "uuid";
import AddTask from "./components/AddTask" ;
import TaskList from "./components/TaskList";

function App() {
  // Store tasks in local storage
  const LOCAL_STORAGE_KEY ="tasks" ;
  
  const [tasks, setTasks] = useState(
    JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY)) ?? []
  ) ;

  const addTaskHandler =(task)=>{
    setTasks([...tasks,{id:uuid(), ...task}]) ;
  } ;


  // To persist data, should not be lost on refresh
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  return (
    <div className="App">
      <AddTask addTaskHandler={addTaskHandler}/>
      <TaskList tasks={tasks}/> 
    </div>
  );
}

export default App;
