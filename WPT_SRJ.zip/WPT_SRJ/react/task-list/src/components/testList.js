import React from "react"

const TempList = (props)=>{
       
    return(
        <div>
        Name : {props.temp.name} ;
        Age : {props.temp.age} ;
    </div>
    )  ;  
}
export default TempList ;