Open frameset.html
