const http = require("http");
const url = require("url");
const fs = require("fs");
const mod = require("./myModule")


const server = http.createServer((req, resp) => {
    resp.writeHeader(200, { "content-type": "text/html" })
    var q = url.parse(req.url, true);
    console.log(q);
    switch (q.pathname) {
        case "/home":
            var rs = fs.createReadStream("node js/Node lab/prob 2/form.html");
            rs.pipe(resp);
            break;

        case "/submit-data":
            resp.write("Num:" + q.query.num+ "<br>")
            // resp.write("btn1:" + q.query.btn1)
            if ((q.query.num) < 5) {
                var result = mod.factorial([q.query.num]);
                resp.end("Factorial of number is" + result)

            }
            else if ((q.query.num) > 5 && (q.query.num) < 10) {
                var result = mod.printable([q.query.num]);

                resp.end("Printing table of number :" + result)
            }
            else {
                var result = mod.prime([q.query.num]);
                if (result == true) {

                    resp.end("Number is a prime")
                }
                else{
                    
                    resp.end("Number is not a prime")
                }
            }
            // rs.pipe(resp);
            // resp.end();
            break;

        default:
            resp.write("<h2>in some other page</h2>")
            resp.end();
    }
})
server.listen(3001, function () {
    console.log("server started at port 3001")
})