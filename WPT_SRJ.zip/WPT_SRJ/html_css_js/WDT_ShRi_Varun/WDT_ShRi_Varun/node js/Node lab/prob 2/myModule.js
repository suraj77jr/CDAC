function factorial(num1) {
    var num = 1;
    for (var i = 1; i <= num1; i++) {
        num = num * i;
    }
    return num;
}

// function prime(num1) {
//     for (var i = 2; i < num1; i++) {
//         var res = num1 % i;
//         if (res === 0) {
//             return false;
            
//         }
        
//         return true;
//     }
// }
function prime(num1) {
    if (num1 <= 1) {
        return false;
    }
    for (let i = 2; i <= Math.sqrt(num1); i++) {
        if (num1 % i === 0) {
            return false;
        }
    }
    return true;
}


function printable(num1) {
    var arr = []
    for (var i = 1; i <= 10; i++) {
        arr[i] = num1 * i;

    }
    return arr;
}

module.exports =
{
    factorial: factorial,
    prime: prime,
    printable: printable
}