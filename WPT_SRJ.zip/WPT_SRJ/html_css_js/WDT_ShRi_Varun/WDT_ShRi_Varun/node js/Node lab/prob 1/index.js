const { log } = require("console");
// const http=require("http");
// const server=http.createServer(function(req,resp){
//     console.log(req.url);

// })
// server.listen(3001,function(){
//     console.log("server is running at port 3001");
// })

console.log("this is index.js");
const mod = require("./calc")

// console.log(mod);
console.log(mod.addition([20, 5, 5]));
console.log(mod.subtraction([20, 5, 5]));
console.log(mod.multiplication([20, 5, 5]));
console.log(mod.division([20, 5, 4]));