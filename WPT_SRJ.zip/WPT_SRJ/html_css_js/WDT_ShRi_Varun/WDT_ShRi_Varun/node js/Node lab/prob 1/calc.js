const { log } = require("console");

console.log("this is calc module");
addition = function (arr) {
    var sum = 0;
    arr.forEach(element => {
        sum += element;
    });
    return `The sum of numbers is ${sum}`;

}
subtraction = function (arr) {
    var subtract = arr[0];
    // console.log(subtract);

    for (var i = 1; i < arr.length; i++) {
        // console.log(arr[i]);
        subtract -= arr[i];
    }
    return `The subtraction of numbers is ${subtract}`;

}
multiplication = function (arr) {
    var multiply = arr[0];

    for (var i = 1; i < arr.length; i++) {
        // console.log(arr[i]);
        multiply *= arr[i];
    }
    return `The multiplication of numbers is ${multiply}`;

}

division = function (arr) {
    var division1 = arr[0];

    for (var i = 1; i < arr.length; i++) {
        // console.log(arr[i]);
        division1 /= arr[i];
    }
    return `The division of numbers is ${division1}`;

}
// console.log(addition([3,4]));
module.exports = {
    addition: addition,
    subtraction: subtraction,
    multiplication: multiplication,
    division: division,
    name: "varun"
}