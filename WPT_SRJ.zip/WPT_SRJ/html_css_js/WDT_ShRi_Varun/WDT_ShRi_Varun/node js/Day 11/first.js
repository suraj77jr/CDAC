console.log("Hello World!!")
console.error("This is error");