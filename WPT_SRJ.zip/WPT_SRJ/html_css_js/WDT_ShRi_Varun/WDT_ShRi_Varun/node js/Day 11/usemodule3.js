var m3=require("./module3");
m3.f1(23,45);
m3.f2(5)
console.log(m3.user.uname);