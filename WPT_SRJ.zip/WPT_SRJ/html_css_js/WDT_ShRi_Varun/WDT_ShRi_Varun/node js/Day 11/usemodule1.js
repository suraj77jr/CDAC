const m1=require("./module1")
var ans=m1.addition(12,13);
console.log("Addition : ",ans);
m1.f1()
m1.printatble(7);