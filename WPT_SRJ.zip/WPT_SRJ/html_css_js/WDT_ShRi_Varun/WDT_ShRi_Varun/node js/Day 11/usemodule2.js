const m2=require("./module2");
m2.f2();

console.log("userid: ",m2.user.userid)