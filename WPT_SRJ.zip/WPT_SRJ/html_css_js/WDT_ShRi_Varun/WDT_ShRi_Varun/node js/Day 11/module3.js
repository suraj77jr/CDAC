function addition(a,b){
    console.log("in addition function")

}

function factorial(num){
    console.log("in factorial function")
}

var user={uid:123,uname:"Kishori",addr:"baner"};

module.exports={
    f1:addition,
    f2:factorial,
    user:user
}