package searching;

import java.util.Arrays;
import java.util.Scanner;

public class SearchingMain {
	
	// Works for any array
	public static int searchLinear(int[] array, int key){
		for (int i=0; i<array.length; i++) {
			if(key==array[i])
				return i;
		}
		return -1;
	}
	
	// Works for sorted array only
	public static int searchBinary(int[] array, int key) {
		int lowerIndex=0, higherIndex=array.length-1, midIndex;
		
		while(lowerIndex<=higherIndex) {
			midIndex=(lowerIndex+higherIndex)/2;
			if(key==array[midIndex])
				return midIndex;
			else{
				if(key<midIndex)
					higherIndex=midIndex-1;
				else
					lowerIndex=midIndex+1;
			}
		}
		return -1;	
	}
	
	// Works for sorted array only
	// Think recursive function in-line code and not as loops 
		public static int searchRecBinary(int[] array, int lowerIndex, int higherIndex, int key) {
			
			// condition for terminating
			if(lowerIndex>higherIndex)
				return -1;
			
			// Body of function
			int index, midIndex=(lowerIndex+higherIndex)/2;
			
			if(key==array[midIndex])
				return midIndex;
			
			if(key<midIndex)
				index=searchRecBinary(array, lowerIndex, midIndex-1, key);
			else
				index=searchRecBinary(array, midIndex+1, higherIndex, key);
			return index;
		}
	


	public static void main(String[] args) {
		int[] array= {2,5,3,5,9,4,56,7,98};
		Arrays.sort(array);		// As its static method
		
		try(Scanner sc = new Scanner(System.in)){
			System.out.println("Enter the key to Search: ");
			int key=sc.nextInt();
			
			int indexLinear=searchLinear(array, key);
			if (indexLinear==-1)
				System.out.println("The key is not found");
			else
				System.out.println("The key is found at index: " + indexLinear);
			
			int indexBinary=searchBinary(array, key);
			if (indexBinary==-1)
				System.out.println("The key is not found");
			else
				System.out.println("The key is found at index: " + indexBinary);
			
			int indexRec=searchRecBinary(array, 0, array.length-1, key);
			if (indexRec==-1)
				System.out.println("The key is not found");
			else
				System.out.println("The key is found at index: " + indexRec);

			
		}	//try
	}	//main
}	//class
