package bstree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

class BinarySearchTree{
	
	//******** Static class for node***********
	static class Node{
		// Instance variables for node
		private int data;
		private Node left, right;
		
		public Node(){
			// Constructor to create node with default values
		}
		
		// Concstructor to create node with data initialized
		public Node(int data) {
			this.data=data;
		}
		
		//Getter to access the data field in main
		public int getData() {
			return data;
		}
		
	}
	//*****************************************
	
	// Tree fields
	private Node root;
	
	public BinarySearchTree() {
		// To construct empty binary tree
	}
	
	// Tree Methods
	
	public void add(int data) {
		// Create node and initialize with data
		Node newNode=new Node(data);
		// If empty --> make newNode root Node
		if(root==null)
			root=newNode;
		else {
			// Traverse till you reach leaf according to conditons
			Node trav=root;
			boolean added=false;
			// Do further steps till newNode gets added
			while(!added) {
				if(newNode.data<trav.data) {
					// if no child in left
					if(trav.left==null) {
						trav.left=newNode;
						added=true;	// break can also be used here
					}
					else
						trav=trav.left;
				}
				else {
					// if no child in right
					if(trav.right==null) {
						trav.right=newNode;
						added=true;	// break can also be used here
					}
					else
						trav=trav.right;
				}
			}	
		}	
	}

	// We have to traverse from root, but we can't access root in main
	// So, writing wrapper method below
	public void preOrder(Node trav) {
		if(trav==null)
			return;
		System.out.print(trav.data + " ");
		preOrder(trav.left);
		preOrder(trav.right);
	}
	
	// Wrapper method to call above method with root as argument
	// No absolute need of this, we could have done this by simply defining the getters
	public void preOrder() {
		System.out.print("Pre Order: ");
		preOrder(root);
		System.out.println("");
	}
	
	// Similar logic for the In-order and Post-order
	public void inOrder(Node trav) {
		if(trav==null)
			return;
		inOrder(trav.left);
		System.out.print(trav.data + " ");
		inOrder(trav.right);
	}
	public void inOrder() {
		System.out.print("In Order: ");
		inOrder(root);
		System.out.println("");
	}
	

	public void postOrder(Node trav) {
		if(trav==null)
			return;
		postOrder(trav.left);
		postOrder(trav.right);
		System.out.print(trav.data + " ");
	}
	public void postOrder() {
		System.out.print("Post Order: ");
		postOrder(root);
		System.out.println("");
	}
	
	public void deleteAll() {
		root=null;
	}
	
	public int findHeight(Node node) {
		if(node==null)
			return -1;
		if(findHeight(node.left)>findHeight(node.right))
			return findHeight(node.left)+1;
		else 
			return findHeight(node.right)+1;
	}
	public int findHeight() {
		return findHeight(root);
	}
	
	//********* Searching methods in Tree ****************
	
	// Breadth first search
	public Node bfSearch(int key) {
		Queue<Node> nodeQueue = new LinkedList<>();
		nodeQueue.offer(root); // offer method is preferable over add
		Node trav=null;
		while(!nodeQueue.isEmpty()) {
			trav=nodeQueue.poll();
			if(key==trav.data)
				return trav;
			else {
				if(trav.left!=null)
					nodeQueue.add(trav.left);
				if(trav.right!=null)
					nodeQueue.add(trav.right);
			}			
		}
		return null;
	}
	
	// Depth first search
	public Node dfSearch(int key) {
		Stack<Node> nodeStack = new Stack<>();
		nodeStack.add(root); // offer method is preferable over add
		Node trav=null;
		while(!nodeStack.isEmpty()) {
			trav=nodeStack.pop();
			if(key==trav.data)
				return trav;
			else {
				if(trav.right!=null)
					nodeStack.add(trav.right);
				if(trav.left!=null)
					nodeStack.add(trav.left);		
			}			
		}
		return null;
	}
		
	// Binary Search
	public Node BinarySearch(int key) {
		Node trav=root;
		while(trav!=null) {
			if(key==trav.data)
				return trav;
			else {
				if(key<trav.data)
					trav=trav.left;
				else
					trav=trav.right;
			}
		}
		return null;
	}
	
	// Binary Search with Parent
	public Node[] BinarySearchWithParent(int key) {
		Node[] travPair= {root, null};	// trav, travParent 
		while(travPair[0]!=null) {
			if(key==travPair[0].data)
				return travPair;
			else {
				if(key<travPair[0].data) {
					travPair[1]=travPair[0];
					travPair[0]=travPair[0].left;	
				} 
				else {
					travPair[1]=travPair[0];
					travPair[0]=travPair[0].right;
				}
			}
		}
		return null;
	}
	
	//******************************************************
	
}//class





public class BSTreeMain {
	public static void main(String[] args) {
		BinarySearchTree tree=new BinarySearchTree();
		tree.add(50);
		tree.add(30);
		tree.add(10);
		tree.add(90);
		tree.add(100);
		tree.add(40);
		tree.add(70);
		tree.add(80);
		tree.add(60);
		tree.add(20);
		
		
		
		
		
		//tree.preOrder();
		//tree.deleteAll();
		//tree.inOrder();
		//tree.postOrder();
//		System.out.println(tree.bfSearch(100).getData());
//		System.out.println(tree.dfSearch(100).getData());
//		System.out.println(tree.BinarySearch(100).getData());
//		System.out.println(tree.BinarySearchWithParent(100)[0].getData()
//				// Below line will give exception when trav=root and travParent=null
//						+ " " + tree.BinarySearchWithParent(100)[1].getData());
		
		//System.out.println("Height: " + tree.findHeight());
		
		
		
		
		
	}//main
}//class
