package recursion;

import java.util.Scanner;

public class recursionMain {
	
	public static int findFactorial(int num) {
		int factorial=num;
		if(num==0)
			return 1;
		factorial = factorial * findFactorial(num-1);
		return factorial;
	}
	
	public static int calcPower(int num, int raisedTo) {
		int power=num;
		if (raisedTo==0)
			return 1;
		power= power*calcPower(num, raisedTo-1);
		
		return power;
	}
	
	public static void printfibonacci(int totalEle) {
		int firstEle=0, secondEle=1, thirdEle;
		for(int i=1; i<=totalEle; i++) {
			System.out.print(" " + firstEle);
			thirdEle=firstEle+secondEle;
			firstEle=secondEle;
			secondEle=thirdEle;
		}	
	}
	
	public static int findnthEleFibonacciRec(int nthEle) {
		if(nthEle==0)
			return 0;
		if(nthEle==1 || nthEle==2)
			return 1;
		
		return findnthEleFibonacciRec(nthEle-1)+findnthEleFibonacciRec(nthEle-2);
	}
	
	
	public static void main(String[] args) {
//		System.out.println("Enter the number to calc factorial");
		try(Scanner sc = new Scanner(System.in)){
//			
//			int num = sc.nextInt();
//			int factorial=findFactorial(num);
//			System.out.println("Factorial of " + num + " is " + factorial);
			
			
//			System.out.println("Enter the number and raisedTo to calc power");	
//			int num = sc.nextInt(), raisedTo=sc.nextInt();
//			int power=calcPower(num, raisedTo);
//			System.out.println(raisedTo +" th power of " + num + " is " + power);
		
//			printfibonacci(10);
//			System.out.println("");
//			
//			for(int i=0; i<=9; i++) {
//				System.out.print(" " + findnthEleFibonacciRec(i));
//			}
			
			
		}//try
	}// main
}// class
