package singlycircularlist;

import java.util.Scanner;

////////////// NOT WORKING ////////////////////

class SinglyCircularList {		// Cannot be public, Gives compilation error
	
	private Node head;
	
	public SinglyCircularList() {
		// TO create empty LL with head = null;
	}
	
	// Static member class --> Node class (self referential class)
	static class Node{
		private int data;
		private Node next;
		
		// Creates node with next=null and data=0;
		public Node() {
		}
				
		// Creates node with next=null and given data
		public Node(int data) {
			this.data=data;
		}
		
	}	// Static class
	
	// CRUD methods
	public void displayAll() {
		if(head==null)
			System.out.println("List is Empty");
		else {
			Node trav=head;
			{
				System.out.print(trav.data+ " ");
				trav=trav.next;
			} while(trav!=head) 
			System.out.println("");	
		}
	}
	
	public void addAtFirst(int data) {
		Node newNode=new Node(data);
		if(head==null) {
			newNode.next=newNode;
			head=newNode;
		}else {
			Node trav=head;
			while(trav.next!=head)
				trav=trav.next;
			newNode.next=head;
			trav.next=newNode;
			head=newNode;
		}
	}
	
	public void addAtLast(int data) {
		Node newNode=new Node(data);

		if(head==null) {		// Special case
			head=newNode;
			newNode.next=newNode;
		}
		else {				// Generic case
			Node trav=head;
			while(trav.next!=head)
				trav=trav.next;
			newNode.next=head;
			trav.next=newNode;
		}
	}
	
	public void addAtPos(int pos, int data) {		
		
		//Special case
		if(pos<1)
			throw new RuntimeException("Invalid Index");
		else {
			if(pos==1)
			addAtFirst(data);
			else {
				// Generic case
				Node newNode=new Node(data);
				Node trav=head;
				for(int i=2; i<=pos-1; i++) {	// To reach nth node you need n-1 iterations, 
					trav=trav.next;				// This loop not valid for pos=1, we have handled it above
					if(trav==head)
						throw new RuntimeException("Invalid Index");
				}								// i indicates --> the node on which you are on
				newNode.next=trav.next;			// Started from i=2 as if loop runs once you will be on 2nd node 
				trav.next=newNode;
			}
		}
	}
	
	public void deleteAll() {
		head=null;
	}
	
	public void deleteAtPos(int pos) {
		if(head==null || pos<1)
			throw new RuntimeException("Invalid position or List is empty");
		else { 
			if(pos==1)
				if(head==head.next)
					head=null;
				else
					head=head.next;
			else {
				Node trav=head;
				for(int i=2; i<=pos-1; i++) {
					trav=trav.next;
					if(trav.next==head)
						throw new RuntimeException("Invalid position");
				}
				trav.next=trav.next.next;
			}
		}
	}
	
	public void deleteLast() {
		
		// Special case
		if(head==null)
			throw new RuntimeException("List is already empty!!");
		else if(head.next==head)
			head=null;
		else {
			// For generic case for LL containing more than 1 node
			Node trav=head;
			Node prevTrav=head;
			while(trav.next!=head) {
				prevTrav=trav;
				trav=trav.next;
			}
			prevTrav.next=null;
		}
	}
} //Class
		
public class SinglyCircularListMain{ 
	public static void main(String[] args) {
		
		int choice, val, pos;
		SinglyCircularList list = new SinglyCircularList();
		try(Scanner sc = new Scanner(System.in)) {
			do {
				System.out.println("\n0. Exit\n1. Display\n2. Add First\n3. "
						+ "Add Last\n4. Add At Pos\n6. Del Last\n7. "
						+ "Del At Pos\n8. Del All\nEnter choice: ");
				System.out.println("");
				choice = sc.nextInt();
				switch (choice) {
				case 1: // Display
					list.displayAll();
					break;
				case 2: // Add First
					System.out.print("Enter new element: ");
					val = sc.nextInt();
					list.addAtFirst(val);
					break;
				case 3: // Add Last
					System.out.print("Enter new element: ");
					val = sc.nextInt();
					list.addAtLast(val);
					break;
				case 4: // Add At Pos
					System.out.print("Enter element position: ");
					val = sc.nextInt();
					System.out.print("Enter new element: ");
					pos = sc.nextInt();
					list.addAtPos(val, pos);				
					break;
				
				case 6: // Del Last
					try {
						list.deleteLast();
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 7: // Del At Pos
					System.out.print("Enter element position: ");
					pos = sc.nextInt();
					try {
						list.deleteAtPos(pos);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 8: // Del All
					list.deleteAll();
					break;
				}
			} while(choice!=0);
		}

	} //main

} // class
