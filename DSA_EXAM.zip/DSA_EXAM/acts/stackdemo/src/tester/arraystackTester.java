package tester;
import stack.arrayStack;

public class arraystackTester {

	public static void main(String[] args) {
		arrayStack s1=new arrayStack();
		try {
		s1.push(12);
		s1.push(22);
		s1.push(32);
		s1.push(42);
		s1.push(52);
		//s1.push(53);
		
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		//System.out.println(s1.pop());

		}catch (Exception e) {
			System.out.println(e);
		}		
		
	}

}
