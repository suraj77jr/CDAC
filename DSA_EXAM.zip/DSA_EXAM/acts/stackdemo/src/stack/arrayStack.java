package stack;
public class arrayStack{
	
	private int size;					 		// Size of the stack
	private int top; 	 				 		// Index of the top element
	private int[] stackArray; 	 		// Array to store stack elements
	
	public arrayStack() {					// Default Constructor to Instanciate Stack
		size=10;									// With Fixed predefined size
		stackArray = new int[size];	// 
		top=-1;
	}
	
	public arrayStack(int s) {
		size=s;
		stackArray = new int[size];
		top=-1;
	}
	
	public void push (int val) throws Exception {
		if(!isFull())
			stackArray[++top]=val;
		else
			throw new Exception("Overflow!");
	}
	
	public  int pop() throws Exception {
		if(!isEmpty())	
			return stackArray[top--];
		else
			throw new Exception("Underflow!");
	}
	
	public boolean isEmpty() {
		if(top==-1)
			return true;
		else
		return false;
	}
	
	public boolean isFull() {
		if(top==(size-1))
			return true;
		else
		return false;
	}
	
	public int peek() {
		return stackArray[top];
	}
}

