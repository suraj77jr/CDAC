package array;

import java.util.ArrayList;
import java.util.List;

public class arrayListBasics {

	public static void main(String[] args) {
		// Java ArrayList is a part of the Java collection framework and it is a class of java.util package.
		//  It provides us with dynamic arrays in Java.
		//  The main advantages of Java ArrayList are, it is not needed to mention the size of ArrayList 
		//  if you want to mention the size then you can do it.
		//  the collection grows or shrinks if the objects are removed from the collection.
		 ArrayList<Integer> arr1 = new ArrayList<Integer>(n);
		 int size=5;
		 ArrayList<Integer> arr2 = new ArrayList<Integer>(size);
		 // Printing the ArrayList
	      System.out.println(arr1);
	     // Appending new elements at the end of the list
	      int i=5;
	      arr1.add(i);
	      // Java ArrayList allows us to randomly access the list.
	     //  ArrayList can not be used for primitive types, like int, char, etc. We need a wrapper class for such cases.
	      
	      // Constructors in arrayList
	      ArrayList arr3 = new ArrayList(); // This constructor is used to build an empty array list.
	      List c; 
	      // This constructor is used to build an array list initialized with the elements from the collection c.
	      ArrayList arr4 = new ArrayList(c); 
	      // This constructor is used to build an array list with the initial capacity being specified
	      ArrayList arr5 = new ArrayList(size);
	      
	      // This method is used to insert a specific element at a specific position index in a list.
	      arr5.add(1, 2); // add(int index, Object element)
		
	      // This method is used to append a specific element to the end of a list
	      arr5.add(5); // add(Object o)
	      
	      // This method is used to append all the elements from a specific collection to the end of the mentioned list
	      arr5.addAll(arr4); // addAll(Collection C)
	      
	      // This method is used to remove all the elements from any list.
	      arr3.clear(); // clear()
	      
	      // Returns true if this list contains the specified element.
	      arr5.contains(5);// boolean contains (Object o)
	      
	      // Returns the element at the specified position in this list.
	      arr5.get(1);// get(int index)
	      
	     //  The index the first occurrence of a specific element is either returned or -1 in case the element is
	     //not in the list.
	      arr5.indexOf(5);// indexOf(Object O)
	      
	      // Returns the number of elements in this list
	      arr5.size(); //size()
	      // Removes the element at the specified position in this list.
	     // remove(int index)
	      
	      // Removes the first occurrence of the specified element from this list, if it is present.
	     // remove (Object o)
	      
	     // Removes from this list all of its elements that are contained in the specified collection.
	     // removeAll(Collection c)
	      
	     // Removes all of the elements of this collection that satisfy the given predicate.
	     //removeIf(Predicate filter)
	      
	      // This method is used to return an array containing all of the elements in the list in the correct order.
	      // toArray()
	      
//	      ** Some Key Points of ArrayList:
	      
//	      1.  ArrayList is Underlined data Structure Resizable Array or Growable Array.
//	      2. ArrayList Duplicates Are Allowed.
//	      3.  Insertion Order is Preserved.
//	      4. Heterogeneous objects are allowed.
//	      5. Null insertion is possible.
	      
//	      **Disadvantages of ArrayList:
//	      1. Slower than arrays: ArrayList is slower than arrays for certain operations, such as inserting elements in the
//		      middle of the list.
//	      2. Increased memory usage: ArrayList requires more memory than arrays, as it needs to maintain its dynamic
//	          size and handle resizing.
		
	} // main
}	// class
