package array;

public class arrayBasics {

	public static void main(String[] args) {
		
		// In Java, all arrays are dynamically allocated; int[] x = new int[someVariable] 	
		// Arrays are stored in contiguous memory
		// Java array can be used as a static field, a local variable, or a method parameter.
		// The direct superclass of an array type is Object.
		// This storage of arrays helps us randomly access the elements of an array [Support Random Access].
		// The size of the array cannot be altered (once initialized)
		// Array class has only static methods.
		int[] intArray; 
		// Although the first declaration establishes that int Array is an array variable, no actual array exists. 
		// It merely tells the compiler that this variable (int Array) will hold an array of the integer type. 
		// To link int Array with an actual, physical array of integers, you must allocate one using new. 
		intArray =  new int[20]; 
		//	Student[] studentArray =  new Student[20]; 
		//	Student[] studentArray =  new Student[] {new Student()}; 

		// The elements in the array allocated by new will automatically be initialized to zero (for numeric types), 
		// false (for boolean), or null (for reference types).
		//In a situation where the size of the array and variables of the array are already known,
		int[] intArray2 = new int[] {1, 2, 3};	//Array constants can be only used in initilization 
		int[] intArray3 = {1, 2, 3};
		// Accessing elements of array
		for (int i=0; i < intArray.length; i++) {
			//System.out.println(i + " " + intArray[i]);
		}
		
		for ( int i : intArray2	) {
			//System.out.println(i);
		}
		
		// Multidimensional arrays are arrays of arrays with each element of the array holding the 
		// reference of other arrays
		int size=5;
		double[][] doubleArray = new double[size][size]; 		// Similarly for n dimensions
		double[][] doubleArray2 = { { 2, 7, 9 }, { 3, 6, 1 }, { 7, 4, 2 } };	// Each inner brace represents row
		System.out.println(doubleArray2[0][1]);	// row, column
		
		
		
	}	// Main
}	// Class
