package linkedlist;

public class SinglyLinkedList {
	
	// Instance variable
	private Node head;	// Singly LL won't have tail
	
	// Default constructor to create empty linked list 
	public SinglyLinkedList() {	
		head=null;
	}
	
	// Methods for operations on linked list 
	public void addAtEnd(int data) {
		
		Node newNode = new Node();	// to add data at end, first we are creating the next node
		newNode.setData(data);		// put data in Node
		newNode.setNextNodeRef(null);	// as its last node, we don't directly have ref of last node in SinglyLL
		
		// Add created node to the SinglyLL
		if(head==null)
			head=newNode;	// Create 1st node of SinglyLL
		else {
			Node currentNodeRef=head;
			while(currentNodeRef.getNextNodeRef()!=null) {		//  traverse till last node
				currentNodeRef=currentNodeRef.getNextNodeRef();	//  get nextNodeRef of node
			}
			currentNodeRef.setNextNodeRef(newNode);				//	set last node ref from null to newnode
		}		
	}
	
	public void addAtBegin(int data) {	// No need to check if the LL is empty
			
			Node newNode = new Node();	// Create Node
			newNode.setData(data);		// Add data in node	
			newNode.setNextNodeRef(head);	// set nextNode ref of new node, if LL is empty --> head is null
			head=newNode;					// change head to new node
	}
	
	public void addAtPosition(int data, int pos) {
		
	
	}
	
	public void removeFromBegin() {
		
	}
	
	public void removeFromEnd() {
		
	}
	
	public void removeFromPosition(int pos) {
		
	}
	
	public void show() {	// Method to show all elements in singlyLL
		Node travPointer=head;
		while(travPointer.getNextNodeRef()!=null) {
			travPointer.getNextNodeRef();
			System.out.println(travPointer.getData() + "  ");
		}
	}



}	// Class
