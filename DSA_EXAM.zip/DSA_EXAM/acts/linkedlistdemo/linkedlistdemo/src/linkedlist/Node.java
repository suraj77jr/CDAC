package linkedlist;

class Node{
	
	// Instance variable
	private int data;
	private Node nextNodeRef;
	
	// Getters and Setters
	public int getData() {
		return data;
	}
	
	public void setData(int data) {
		this.data = data;
	}

	public Node getNextNodeRef() {
		return nextNodeRef;
	}

	public void setNextNodeRef(Node nextNodeRef) {
		this.nextNodeRef = nextNodeRef;
	}
	
	
	
	
	

	
	
	
}	// Class