package tester;

import linkedlist.SinglyLinkedList;

public class LinkedListTester {
	public static void main(String[] args) {
		
	SinglyLinkedList list1 = new SinglyLinkedList();
	list1.addAtEnd(1);
	
		
		
		
		
		
		
		
		
	}
}
