package sorting;

import java.util.Arrays;

public class SortingMain {
		
	public static int[] sortSelection(int[] array) {
		int temp;
		for(int i=0; i<=array.length-2; i++) {
			for(int j=i+1; j<=array.length-1; j++){
				if(array[i]>array[j]) {
					temp=array[i]; array[i]=array[j]; array[j]=temp;
				}
			}
		}
		return array;		
	}//method
	
	public static int[] sortBubble(int[] array) {
		int temp;
		boolean swapFlag;
		for(int i=0; i<=array.length-1; i++) {	// Pass loop
			swapFlag=false;
			for(int j=0; j<=array.length-2-i; j++){
				if(array[j]>array[j+1]) {
					temp=array[j]; array[j]=array[j+1]; array[j+1]=temp;
					swapFlag=true;
				}
			}
			if(swapFlag==false)
				break;				
		}
		return array;		
	}//method
	
	public static int[] sortInsertion(int[] array) {
		int lastIndex;
		for(lastIndex=1; lastIndex<=array.length-1; lastIndex++) {

			/********** INSERTION TECHNIQUE *****************/
			int temp=array[lastIndex], i;
			for(i=lastIndex-1; (i>=0) && (array[i]>temp); i--) {
				array[i+1]=array[i];
			}
			// i will go up to -1 as,
			// int i; for(i=3; i>=0; i--);
			// print (i) ---> -1;
			array[i+1]=temp;
			/************************************************/
		}
		return array;
	}
	
	//************ Merge Sort (Using recursion) ********************
	
	public static void mergeSort(int[] arr, int left, int right) {
		
		// BASE CONDITION FOR RECURSION: 
		// if partition is invalid to partition has single element
		if(left>=right)
			return;
		
		// Divide the array in two equal parts
		int mid=(left+right)/2;
		
		// Sort left partition [left to mid]
		mergeSort(arr, left, mid);
		// Sort the right partition [mid+1 to right]
		mergeSort(arr, mid+1, right);
		
		// Create temporary array which can accommodate both arrays
		int[] temp = new int[right-left+1];
		
		//*********** Merge two sorted partition into temporary array
		int i = left, j=mid+1, k=0;
		// Compare elements from both partition and copy smaller to temporary and increase the index
		while(i<=mid && j<=right) {
			if(arr[i]<arr[j])
				temp[k++]=arr[i++];
			else
				temp[k++]=arr[j++];
				// Do this till one of the array gets exhausted
		}
		// Append elements from remaining array to temporary array
		while(i<=mid) {
			temp[k++]=arr[i++];
		}
		while(j<=right) {
			temp[k++]=arr[j++];
		}
		//****************
		// Overwrite temporary array back to the original array
		for(i=0; i<temp.length; i++)
			arr[left+i]=temp[i];
	}
	//*******************************************
	
	//************* Quick Sort ******************
	
	public void quickSort(int[] arr,int left, int right) {
		// Consider left as pivot
		// From left find i for element greater than pivot
		// From right find j for element less than or equal to pivot
		// 
		
		
		
		
		
	}//Method
	// ******************************************
	
	public static void main(String[] args) {
	
		int[] intArray= {34,1,-2,55,111,0,-1,-5,-1000, 10000, 4};
		System.out.println("Before sorting: " + Arrays.toString(intArray));
//		int[] sortedArray=sortInsertion(intArray);
//		System.out.println(Arrays.toString(intArray));
//		System.out.println(Arrays.toString(sortedArray));
		mergeSort(intArray, 0, intArray.length-1);
		System.out.println("After sorting " + Arrays.toString(intArray));

		
		

	}// main
}// class
